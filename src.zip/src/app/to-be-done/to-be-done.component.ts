import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-to-be-done',
  templateUrl: './to-be-done.component.html',
  styleUrls: ['./to-be-done.component.css']
})
export class ToBeDoneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
